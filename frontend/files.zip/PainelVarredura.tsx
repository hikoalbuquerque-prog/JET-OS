// src/components/Varredura/PainelVarredura.tsx
import { useState, useRef, useCallback } from 'react';
import { useTranslation } from 'react-i18next';

interface ResultadoIA {
  aprovado: boolean;
  larguraEstimada: string;
  observacoes: string;
  confianca: string;
  score: number;
  motivoCodigo: string;
}

interface PontoVarredura {
  lat: number; lng: number;
  label: string;
  resultado?: ResultadoIA | null;
  status: 'pendente' | 'analisando' | 'ok' | 'erro';
}

interface Props {
  map: google.maps.Map | null;
  onFechar: () => void;
  onAnalisarIA: (lat: number, lng: number, codigo?: string) => Promise<unknown>;
  onAddEstacao: (dados: Record<string, unknown>) => Promise<void>;
  showToast: (msg: string, tipo: 'success'|'error'|'warn'|'info') => void;
}

function gerarPontosRaio(
  centerLat: number, centerLng: number, raio: number, espacamento: number
): Array<{lat: number; lng: number}> {
  const pontos: Array<{lat: number; lng: number}> = [];
  const grausPorMetro = 1 / 111320;
  const passoLat = espacamento * grausPorMetro;
  const passoLng = espacamento * grausPorMetro / Math.cos(centerLat * Math.PI / 180);

  for (let dlat = -raio; dlat <= raio; dlat += espacamento) {
    for (let dlng = -raio; dlng <= raio; dlng += espacamento) {
      const dist = Math.sqrt(dlat * dlat + dlng * dlng);
      if (dist > raio) continue;
      pontos.push({
        lat: centerLat + dlat * grausPorMetro,
        lng: centerLng + dlng * passoLng / passoLat
      });
    }
  }
  return pontos;
}

export default function PainelVarredura({ map, onFechar, onAnalisarIA, onAddEstacao, showToast }: Props) {
  const { t } = useTranslation();
  const [raio, setRaio] = useState(500);
  const [rodando, setRodando] = useState(false);
  const [pontos, setPontos] = useState<PontoVarredura[]>([]);
  const [idx, setIdx] = useState(0);
  const [modoEconomico, setModoEconomico] = useState(false);
  const [selecionados, setSelecionados] = useState<Set<number>>(new Set());
  const paradoRef = useRef(false);
  const markersRef = useRef<google.maps.Marker[]>([]);

  const aprovados = pontos.filter(p => p.resultado?.aprovado).length;
  const reprovados = pontos.filter(p => p.resultado && !p.resultado.aprovado).length;

  const limparMarkers = useCallback(() => {
    markersRef.current.forEach(m => m.setMap(null));
    markersRef.current = [];
  }, []);

  const iniciarVarredura = useCallback(async () => {
    if (!map) return;
    const centro = map.getCenter();
    if (!centro) return;

    paradoRef.current = false;
    setRodando(true);
    setSelecionados(new Set());
    limparMarkers();

    const lista = gerarPontosRaio(centro.lat(), centro.lng(), raio, 80);
    const novos: PontoVarredura[] = lista.map((p, i) => ({
      ...p, label: `P${i + 1}`, status: 'pendente'
    }));
    setPontos(novos);
    setIdx(0);

    // Marcadores iniciais
    lista.forEach(p => {
      const m = new google.maps.Marker({
        position: p, map,
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 5, fillColor: '#60a5fa',
          fillOpacity: 0.4, strokeColor: '#60a5fa', strokeWeight: 1
        }
      });
      markersRef.current.push(m);
    });

    // Processa ponto a ponto
    for (let i = 0; i < novos.length; i++) {
      if (paradoRef.current) break;
      setIdx(i);

      setPontos(prev => {
        const copia = [...prev];
        copia[i] = { ...copia[i], status: 'analisando' };
        return copia;
      });

      // Atualiza marker para "analisando"
      if (markersRef.current[i]) {
        markersRef.current[i].setIcon({
          path: google.maps.SymbolPath.CIRCLE,
          scale: 7, fillColor: '#fbbf24',
          fillOpacity: 1, strokeColor: '#fff', strokeWeight: 2
        });
      }

      try {
        const res = await onAnalisarIA(novos[i].lat, novos[i].lng) as { resultado?: ResultadoIA } | null;
        const resultado = (res as { resultado?: ResultadoIA })?.resultado || null;

        setPontos(prev => {
          const copia = [...prev];
          copia[i] = { ...copia[i], status: 'ok', resultado };
          return copia;
        });

        // Cor do marker por resultado
        const cor = resultado?.aprovado ? '#22c55e' : '#ef4444';
        if (markersRef.current[i]) {
          markersRef.current[i].setIcon({
            path: google.maps.SymbolPath.CIRCLE,
            scale: 7, fillColor: cor,
            fillOpacity: 1, strokeColor: '#fff', strokeWeight: 2
          });
        }

        // Auto-seleciona aprovados com score alto
        if (resultado?.aprovado && resultado.score >= 33 && resultado.confianca === 'alta') {
          setSelecionados(prev => new Set([...prev, i]));
        }

      } catch {
        setPontos(prev => {
          const copia = [...prev];
          copia[i] = { ...copia[i], status: 'erro' };
          return copia;
        });
      }

      // Pequeno delay para não sobrecarregar
      await new Promise(r => setTimeout(r, 300));
    }

    setRodando(false);
    showToast(t('varredura.concluida'), 'success');
  }, [map, raio, modoEconomico, onAnalisarIA, showToast, t, limparMarkers]);

  const pararVarredura = () => {
    paradoRef.current = true;
    setRodando(false);
  };

  const toggleSelecionado = (i: number) => {
    setSelecionados(prev => {
      const n = new Set(prev);
      if (n.has(i)) n.delete(i); else n.add(i);
      return n;
    });
  };

  const adicionarLote = async () => {
    const lista = [...selecionados].map(i => pontos[i]).filter(p => p.resultado?.aprovado);
    if (!lista.length) { showToast('Nenhum ponto selecionado', 'warn'); return; }

    showToast(`Adicionando ${lista.length} estações...`, 'info');
    for (const p of lista) {
      try {
        await onAddEstacao({
          lat: p.lat, lng: p.lng,
          tipo: 'PUBLICA', status: 'SOLICITADO',
          calcadaIA: p.resultado ? {
            largura:   p.resultado.larguraEstimada,
            score:     p.resultado.score,
            aprovado:  p.resultado.aprovado,
            confianca: p.resultado.confianca,
            motivo:    p.resultado.motivoCodigo
          } : null
        });
      } catch { /* continua */ }
    }
    showToast(`${lista.length} estações adicionadas!`, 'success');
    setSelecionados(new Set());
  };

  return (
    <div style={{
      position: 'fixed', top: 0, right: 0,
      width: 320, height: '100%',
      background: 'rgba(13,18,30,.97)',
      backdropFilter: 'blur(16px)',
      borderLeft: '1px solid rgba(255,255,255,.08)',
      zIndex: 200, display: 'flex', flexDirection: 'column'
    }}>
      {/* Header */}
      <div style={{
        padding: '16px 20px', borderBottom: '1px solid rgba(255,255,255,.06)',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0
      }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: '#60a5fa' }}>
          {t('varredura.titulo')}
        </div>
        <button onClick={onFechar} style={{
          background: 'rgba(255,255,255,.06)', border: '1px solid rgba(255,255,255,.1)',
          borderRadius: 8, color: 'rgba(255,255,255,.5)', width: 30, height: 30, cursor: 'pointer', fontSize: 16
        }}>×</button>
      </div>

      {/* Controles */}
      <div style={{ padding: '16px 20px', borderBottom: '1px solid rgba(255,255,255,.06)', flexShrink: 0 }}>
        <div style={{ marginBottom: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ fontSize: 12, color: 'rgba(255,255,255,.5)' }}>{t('varredura.raio')}</span>
            <span style={{ fontSize: 12, color: '#60a5fa', fontWeight: 600 }}>{raio}m</span>
          </div>
          <input type="range" min="200" max="2000" step="100"
            value={raio} onChange={e => setRaio(Number(e.target.value))}
            disabled={rodando}
            style={{ width: '100%', accentColor: '#307FE2' }}
          />
        </div>

        {/* Modo econômico */}
        <div style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          padding: '8px 12px', borderRadius: 8,
          background: 'rgba(255,255,255,.03)', marginBottom: 12
        }}>
          <span style={{ fontSize: 12, color: 'rgba(255,255,255,.5)' }}>{t('varredura.modoEconomico')}</span>
          <button onClick={() => setModoEconomico(m => !m)} style={{
            width: 36, height: 20, borderRadius: 10, border: 'none', cursor: 'pointer',
            background: modoEconomico ? '#307FE2' : 'rgba(255,255,255,.15)',
            position: 'relative', transition: '.2s'
          }}>
            <span style={{
              position: 'absolute', top: 2, borderRadius: '50%',
              width: 16, height: 16, background: '#fff', transition: '.2s',
              left: modoEconomico ? 18 : 2
            }} />
          </button>
        </div>

        <button
          onClick={rodando ? pararVarredura : iniciarVarredura}
          style={{
            width: '100%', padding: '12px',
            background: rodando
              ? 'rgba(239,68,68,.15)'
              : 'linear-gradient(135deg,#1a6fd4,#307FE2)',
            border: rodando ? '1px solid rgba(239,68,68,.3)' : 'none',
            borderRadius: 10, color: rodando ? '#f87171' : '#fff',
            fontSize: 13, fontWeight: 600, cursor: 'pointer'
          }}
        >
          {rodando ? `⏹ ${t('varredura.parando')}` : `▶ ${t('varredura.iniciar')}`}
        </button>
      </div>

      {/* Progresso */}
      {pontos.length > 0 && (
        <div style={{
          padding: '10px 20px', borderBottom: '1px solid rgba(255,255,255,.06)',
          display: 'flex', gap: 16, flexShrink: 0
        }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 18, fontWeight: 700, color: '#22c55e' }}>{aprovados}</div>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,.4)' }}>{t('varredura.aprovados')}</div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 18, fontWeight: 700, color: '#ef4444' }}>{reprovados}</div>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,.4)' }}>{t('varredura.reprovados')}</div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 18, fontWeight: 700, color: '#fff' }}>{pontos.length}</div>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,.4)' }}>{t('varredura.pontos')}</div>
          </div>
          {rodando && (
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 18, fontWeight: 700, color: '#fbbf24' }}>{idx + 1}</div>
              <div style={{ fontSize: 10, color: 'rgba(255,255,255,.4)' }}>{t('varredura.analisando')}</div>
            </div>
          )}
        </div>
      )}

      {/* Lista de resultados */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '8px 12px' }}>
        {pontos.filter(p => p.resultado?.aprovado).map((p, i) => {
          const idxReal = pontos.indexOf(p);
          const sel = selecionados.has(idxReal);
          return (
            <div key={i} onClick={() => toggleSelecionado(idxReal)} style={{
              padding: '10px 12px', borderRadius: 8, marginBottom: 6, cursor: 'pointer',
              background: sel ? 'rgba(16,185,129,.1)' : 'rgba(255,255,255,.03)',
              border: `1px solid ${sel ? 'rgba(16,185,129,.3)' : 'rgba(255,255,255,.06)'}`,
              transition: '.15s'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 11, color: '#6ee7b7', fontWeight: 600 }}>✓ {p.label}</span>
                <span style={{ fontSize: 11, color: 'rgba(255,255,255,.4)' }}>
                  Score: {p.resultado?.score}
                </span>
              </div>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,.4)', marginTop: 3 }}>
                {p.resultado?.larguraEstimada || '—'} · {p.resultado?.confianca}
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer com ação lote */}
      {selecionados.size > 0 && (
        <div style={{
          padding: '12px 20px', borderTop: '1px solid rgba(255,255,255,.06)', flexShrink: 0
        }}>
          <button onClick={adicionarLote} style={{
            width: '100%', padding: '12px',
            background: 'linear-gradient(135deg,#059669,#10b981)',
            border: 'none', borderRadius: 10, color: '#fff',
            fontSize: 13, fontWeight: 600, cursor: 'pointer'
          }}>
            + {t('varredura.adicionarLote')} ({selecionados.size})
          </button>
        </div>
      )}
    </div>
  );
}
