// src/components/Drawer/DrawerEstacao.tsx
import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';

interface Props {
  latLng: { lat: number; lng: number } | null;
  onSalvar: (dados: Record<string, unknown>) => Promise<void>;
  onFechar: () => void;
  fnReverseGeocode: () => (data: unknown) => Promise<{ data: unknown }>;
}

const TIPOS = ['PUBLICA', 'PRIVADA', 'CONCORRENTE'];
const STATUS_OPTS = ['SOLICITADO', 'APROVADO', 'REPROVADO', 'INSTALADO'];

export default function DrawerEstacao({ latLng, onSalvar, onFechar, fnReverseGeocode }: Props) {
  const { t } = useTranslation();
  const [salvando, setSalvando] = useState(false);
  const [geo, setGeo] = useState<Record<string, string>>({});
  const [form, setForm] = useState({
    tipo:         'PUBLICA',
    status:       'SOLICITADO',
    larguraFaixa: '',
    observacoes:  '',
    dimensoes:    ''
  });

  // Geocode reverso ao abrir
  useEffect(() => {
    if (!latLng) return;
    fnReverseGeocode()({ lat: latLng.lat, lng: latLng.lng }).then(res => {
      const data = res.data as { ok: boolean; geo?: Record<string, string> };
      if (data.ok && data.geo) setGeo(data.geo);
    }).catch(() => {});
  }, [latLng]);

  const set = (campo: string, valor: string) =>
    setForm(f => ({ ...f, [campo]: valor }));

  const handleSalvar = async () => {
    if (!latLng) return;
    setSalvando(true);
    try {
      await onSalvar({
        lat: latLng.lat,
        lng: latLng.lng,
        tipo:         form.tipo,
        status:       form.status,
        larguraFaixa: form.larguraFaixa || null,
        observacoes:  form.observacoes  || null,
        dimensoes:    form.dimensoes    || null,
        geo,
        pais: geo.pais || 'BR'
      });
    } finally {
      setSalvando(false);
    }
  };

  const inputStyle: React.CSSProperties = {
    width: '100%', padding: '10px 12px',
    background: 'rgba(255,255,255,.06)',
    border: '1px solid rgba(255,255,255,.1)',
    borderRadius: 8, color: '#fff', fontSize: 13,
    outline: 'none', boxSizing: 'border-box'
  };

  const labelStyle: React.CSSProperties = {
    display: 'block', fontSize: 11,
    color: 'rgba(255,255,255,.45)', marginBottom: 6
  };

  return (
    <div style={{
      position: 'fixed', top: 0, right: 0,
      width: 320, height: '100%',
      background: 'rgba(13,18,30,.97)',
      backdropFilter: 'blur(16px)',
      borderLeft: '1px solid rgba(255,255,255,.08)',
      zIndex: 200, display: 'flex', flexDirection: 'column',
      overflowY: 'auto'
    }}>
      {/* Header */}
      <div style={{
        padding: '16px 20px', borderBottom: '1px solid rgba(255,255,255,.06)',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        flexShrink: 0
      }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: '#fff' }}>
          {t('estacao.adicionar')}
        </div>
        <button onClick={onFechar} style={{
          background: 'rgba(255,255,255,.06)',
          border: '1px solid rgba(255,255,255,.1)',
          borderRadius: 8, color: 'rgba(255,255,255,.5)',
          width: 30, height: 30, cursor: 'pointer', fontSize: 16
        }}>×</button>
      </div>

      {/* Conteúdo */}
      <div style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 16, flex: 1 }}>

        {/* Endereço (geocode reverso) */}
        {geo.endereco && (
          <div style={{
            padding: 12, borderRadius: 8,
            background: 'rgba(48,127,226,.08)',
            border: '1px solid rgba(48,127,226,.2)',
            fontSize: 12, color: 'rgba(255,255,255,.6)'
          }}>
            <div style={{ color: '#60a5fa', fontWeight: 600, marginBottom: 4 }}>
              {geo.cidade} · {geo.bairro}
            </div>
            {geo.endereco}
          </div>
        )}

        {/* Lat/Lng */}
        {latLng && (
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,.3)', textAlign: 'center' }}>
            {latLng.lat.toFixed(6)}, {latLng.lng.toFixed(6)}
          </div>
        )}

        {/* Tipo */}
        <div>
          <label style={labelStyle}>{t('estacao.tipo')}</label>
          <div style={{ display: 'flex', gap: 6 }}>
            {TIPOS.map(tipo => (
              <button key={tipo} onClick={() => set('tipo', tipo)} style={{
                flex: 1, padding: '8px 4px', borderRadius: 8, fontSize: 11,
                cursor: 'pointer', transition: '.15s',
                background: form.tipo === tipo ? 'rgba(48,127,226,.25)' : 'rgba(255,255,255,.04)',
                border: `1px solid ${form.tipo === tipo ? 'rgba(48,127,226,.5)' : 'rgba(255,255,255,.08)'}`,
                color: form.tipo === tipo ? '#60a5fa' : 'rgba(255,255,255,.4)'
              }}>
                {t(`estacao.${tipo.toLowerCase()}`)}
              </button>
            ))}
          </div>
        </div>

        {/* Status */}
        <div>
          <label style={labelStyle}>{t('estacao.status')}</label>
          <select
            value={form.status}
            onChange={e => set('status', e.target.value)}
            style={{ ...inputStyle, appearance: 'none' }}
          >
            {STATUS_OPTS.map(s => (
              <option key={s} value={s}>{t(`status.${s}`)}</option>
            ))}
          </select>
        </div>

        {/* Largura faixa */}
        <div>
          <label style={labelStyle}>{t('estacao.larguraFaixa')}</label>
          <input
            type="number" step="0.1" min="0"
            value={form.larguraFaixa}
            onChange={e => set('larguraFaixa', e.target.value)}
            placeholder="ex: 3.5"
            style={inputStyle}
          />
        </div>

        {/* Dimensões */}
        <div>
          <label style={labelStyle}>{t('estacao.dimensoes') || 'Dimensões'}</label>
          <input
            type="text"
            value={form.dimensoes}
            onChange={e => set('dimensoes', e.target.value)}
            placeholder="ex: 2x1m"
            style={inputStyle}
          />
        </div>

        {/* Observações */}
        <div>
          <label style={labelStyle}>{t('estacao.observacoes')}</label>
          <textarea
            value={form.observacoes}
            onChange={e => set('observacoes', e.target.value)}
            rows={3}
            style={{ ...inputStyle, resize: 'vertical', minHeight: 80 }}
          />
        </div>
      </div>

      {/* Footer */}
      <div style={{
        padding: '16px 20px',
        borderTop: '1px solid rgba(255,255,255,.06)',
        display: 'flex', gap: 8, flexShrink: 0
      }}>
        <button onClick={onFechar} style={{
          flex: 1, padding: '12px',
          background: 'rgba(255,255,255,.04)',
          border: '1px solid rgba(255,255,255,.08)',
          borderRadius: 10, color: 'rgba(255,255,255,.5)',
          fontSize: 13, cursor: 'pointer'
        }}>
          {t('estacao.cancelar')}
        </button>
        <button onClick={handleSalvar} disabled={salvando} style={{
          flex: 2, padding: '12px',
          background: salvando ? 'rgba(48,127,226,.3)' : 'linear-gradient(135deg,#1a6fd4,#307FE2)',
          border: 'none', borderRadius: 10, color: '#fff',
          fontSize: 13, fontWeight: 600, cursor: salvando ? 'not-allowed' : 'pointer'
        }}>
          {salvando ? t('app.carregando') : t('estacao.salvar')}
        </button>
      </div>
    </div>
  );
}
