// src/pages/Mapa.tsx
import { useEffect, useRef, useState, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { Loader } from '@googlemaps/js-api-loader';
import { db, fnAddEstacao, fnGerarStreetView, fnAnalisarCalcada, fnReverseGeocode } from '../lib/firebase';
import { useAuth } from '../hooks/useAuth';
import DrawerEstacao from '../components/Drawer/DrawerEstacao';
import PainelVarredura from '../components/Varredura/PainelVarredura';
import PainelCustos from '../components/Custos/PainelCustos';
import InfoEstacao from '../components/Map/InfoEstacao';
import FABGroup from '../components/Map/FABGroup';
import Toast from '../components/Map/Toast';

export interface Estacao {
  id: string;
  codigo: string;
  lat: number;
  lng: number;
  cidade: string;
  bairro: string;
  endereco: string;
  tipo: string;
  status: string;
  pais: string;
  larguraFaixa?: number;
  imagens?: { foto?: string; streetView?: string; croqui?: string };
  ia?: { aprovado: boolean; score: number; confianca: string; largura: string; motivo: string };
  croquiStatus: string;
}

interface Toast { msg: string; tipo: 'success' | 'error' | 'warn' | 'info' }

export default function MapaPage() {
  const { t } = useTranslation();
  const { usuario } = useAuth();

  const mapRef      = useRef<HTMLDivElement>(null);
  const gmapRef     = useRef<google.maps.Map | null>(null);
  const markersRef  = useRef<Map<string, google.maps.Marker>>(new Map());

  const [estacoes,       setEstacoes]       = useState<Estacao[]>([]);
  const [estacaoAtiva,   setEstacaoAtiva]   = useState<Estacao | null>(null);
  const [drawerAberto,   setDrawerAberto]   = useState(false);
  const [varreduraAberta,setVarreduraAberta]= useState(false);
  const [custosAberto,   setCustosAberto]   = useState(false);
  const [modoAdd,        setModoAdd]        = useState(false);
  const [pinLatLng,      setPinLatLng]      = useState<{lat:number;lng:number} | null>(null);
  const [toast,          setToast]          = useState<Toast | null>(null);
  const [mapCarregado,   setMapCarregado]   = useState(false);

  // ── TOAST ────────────────────────────────────────────────────
  const showToast = useCallback((msg: string, tipo: Toast['tipo'] = 'info') => {
    setToast({ msg, tipo });
    setTimeout(() => setToast(null), 3500);
  }, []);

  // ── CARREGAR MAPA ────────────────────────────────────────────
  useEffect(() => {
    const loader = new Loader({
      apiKey: import.meta.env.VITE_GMAPS_KEY,
      version: 'weekly',
      libraries: ['places', 'geometry']
    });

    loader.load().then(() => {
      if (!mapRef.current) return;
      const map = new google.maps.Map(mapRef.current, {
        center: { lat: -23.5614, lng: -46.6558 },
        zoom: 14,
        mapTypeId: 'roadmap',
        disableDefaultUI: true,
        styles: [
          { elementType: 'geometry', stylers: [{ color: '#1a2035' }] },
          { elementType: 'labels.text.fill', stylers: [{ color: '#a0aec0' }] },
          { elementType: 'labels.text.stroke', stylers: [{ color: '#1a2035' }] },
          { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#2d3748' }] },
          { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#0d1220' }] },
          { featureType: 'poi', stylers: [{ visibility: 'off' }] }
        ]
      });

      gmapRef.current = map;
      setMapCarregado(true);

      // Click para add
      map.addListener('click', (e: google.maps.MapMouseEvent) => {
        if (!modoAdd || !e.latLng) return;
        setPinLatLng({ lat: e.latLng.lat(), lng: e.latLng.lng() });
        setDrawerAberto(true);
        setModoAdd(false);
      });
    });
  }, []);

  // ── ESCUTA ESTAÇÕES FIRESTORE ────────────────────────────────
  useEffect(() => {
    if (!usuario) return;
    const pais = usuario.paises[0] || 'BR';
    const q = query(collection(db, 'estacoes'), where('pais', '==', pais));

    const unsub = onSnapshot(q, snap => {
      const lista = snap.docs.map(d => d.data() as Estacao);
      setEstacoes(lista);
    });

    return unsub;
  }, [usuario]);

  // ── RENDERIZA MARKERS ────────────────────────────────────────
  useEffect(() => {
    if (!gmapRef.current || !mapCarregado) return;
    const map = gmapRef.current;

    // Remove markers antigos
    markersRef.current.forEach(m => m.setMap(null));
    markersRef.current.clear();

    estacoes.forEach(e => {
      const cor = e.ia?.aprovado ? '#22c55e'
        : e.tipo === 'PRIVADA' ? '#f59e0b'
        : e.tipo === 'CONCORRENTE' ? '#ef4444'
        : '#3b82f6';

      const marker = new google.maps.Marker({
        position: { lat: e.lat, lng: e.lng },
        map,
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 8,
          fillColor: cor,
          fillOpacity: 1,
          strokeColor: '#fff',
          strokeWeight: 2
        },
        title: e.codigo
      });

      marker.addListener('click', () => {
        setEstacaoAtiva(e);
      });

      markersRef.current.set(e.id, marker);
    });
  }, [estacoes, mapCarregado]);

  // ── ADD ESTAÇÃO ──────────────────────────────────────────────
  const handleSalvarEstacao = useCallback(async (dados: Record<string, unknown>) => {
    try {
      const res = await fnAddEstacao()(dados);
      const data = res.data as { ok: boolean; error?: string };
      if (!data.ok) throw new Error(data.error || 'Erro ao salvar.');
      showToast(t('estacao.adicionar') + ' OK', 'success');
      setDrawerAberto(false);
      setPinLatLng(null);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Erro desconhecido';
      showToast(msg, 'error');
    }
  }, [showToast, t]);

  // ── GERAR STREET VIEW ────────────────────────────────────────
  const handleGerarSV = useCallback(async (estacao: Estacao) => {
    showToast('Gerando Street View...', 'info');
    try {
      const res = await fnGerarStreetView()({
        codigo: estacao.codigo, lat: estacao.lat, lng: estacao.lng
      });
      const data = res.data as { ok: boolean; url?: string; error?: string };
      if (data.ok) showToast('Street View salvo!', 'success');
      else showToast(data.error || 'Sem Street View neste ponto.', 'warn');
    } catch {
      showToast('Erro ao gerar Street View.', 'error');
    }
  }, [showToast]);

  // ── ANALISAR IA ──────────────────────────────────────────────
  const handleAnalisarIA = useCallback(async (lat: number, lng: number, codigo?: string) => {
    try {
      const res = await fnAnalisarCalcada()({ lat, lng, codigo });
      const data = res.data as { ok: boolean; resultado?: unknown; error?: string };
      if (!data.ok) throw new Error(data.error);
      return data.resultado;
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Erro na análise IA';
      showToast(msg, 'error');
      return null;
    }
  }, [showToast]);

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'hidden' }}>
      {/* MAPA */}
      <div ref={mapRef} style={{ width: '100%', height: '100%' }} />

      {/* FAB GROUP */}
      <FABGroup
        onAdd={() => { setModoAdd(true); showToast('Toque no mapa para posicionar', 'info'); }}
        onVarredura={() => setVarreduraAberta(true)}
        onCustos={() => setCustosAberto(true)}
        onCentralizar={() => {
          navigator.geolocation.getCurrentPosition(pos => {
            gmapRef.current?.setCenter({ lat: pos.coords.latitude, lng: pos.coords.longitude });
          });
        }}
        onRecarregar={() => {/* onSnapshot já atualiza automaticamente */}}
        modoAdd={modoAdd}
      />

      {/* INFO ESTAÇÃO */}
      {estacaoAtiva && (
        <InfoEstacao
          estacao={estacaoAtiva}
          onFechar={() => setEstacaoAtiva(null)}
          onGerarSV={() => handleGerarSV(estacaoAtiva)}
          onAnalisarIA={() => handleAnalisarIA(estacaoAtiva.lat, estacaoAtiva.lng, estacaoAtiva.codigo)}
        />
      )}

      {/* DRAWER ADD/EDIT */}
      {drawerAberto && (
        <DrawerEstacao
          latLng={pinLatLng}
          onSalvar={handleSalvarEstacao}
          onFechar={() => { setDrawerAberto(false); setPinLatLng(null); }}
          fnReverseGeocode={fnReverseGeocode}
        />
      )}

      {/* PAINEL VARREDURA */}
      {varreduraAberta && (
        <PainelVarredura
          map={gmapRef.current}
          onFechar={() => setVarreduraAberta(false)}
          onAnalisarIA={handleAnalisarIA}
          onAddEstacao={handleSalvarEstacao}
          showToast={showToast}
        />
      )}

      {/* PAINEL CUSTOS */}
      {custosAberto && (
        <PainelCustos onFechar={() => setCustosAberto(false)} />
      )}

      {/* TOAST */}
      {toast && <Toast msg={toast.msg} tipo={toast.tipo} />}
    </div>
  );
}
