// src/hooks/useAuth.ts
import { useState, useEffect, createContext, useContext } from 'react';
import { onAuthStateChanged, signInWithEmailAndPassword, signOut, User } from 'firebase/auth';
import { auth, fnGetUsuario } from '../lib/firebase';

interface Usuario {
  uid: string;
  email: string;
  nome: string;
  role: 'campo' | 'gestor' | 'admin';
  paises: string[];
}

interface AuthState {
  user: User | null;
  usuario: Usuario | null;
  loading: boolean;
  erro: string | null;
}

interface AuthContext extends AuthState {
  login: (email: string, senha: string) => Promise<void>;
  logout: () => Promise<void>;
  isGestor: boolean;
  isAdmin: boolean;
}

export const AuthCtx = createContext<AuthContext>({} as AuthContext);

export function useAuth() {
  return useContext(AuthCtx);
}

export function useAuthProvider(): AuthContext {
  const [state, setState] = useState<AuthState>({
    user: null, usuario: null, loading: true, erro: null
  });

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          const res = await fnGetUsuario()({});
          const data = res.data as { ok: boolean; usuario: Usuario };
          if (data.ok) {
            setState({ user, usuario: data.usuario, loading: false, erro: null });
          } else {
            setState({ user: null, usuario: null, loading: false, erro: 'Perfil não encontrado.' });
          }
        } catch {
          setState({ user: null, usuario: null, loading: false, erro: 'Erro ao carregar perfil.' });
        }
      } else {
        setState({ user: null, usuario: null, loading: false, erro: null });
      }
    });
    return unsub;
  }, []);

  const login = async (email: string, senha: string) => {
    setState(s => ({ ...s, loading: true, erro: null }));
    try {
      await signInWithEmailAndPassword(auth, email, senha);
    } catch {
      setState(s => ({ ...s, loading: false, erro: 'E-mail ou senha incorretos.' }));
      throw new Error('Login falhou');
    }
  };

  const logout = async () => {
    await signOut(auth);
    setState({ user: null, usuario: null, loading: false, erro: null });
  };

  return {
    ...state,
    login,
    logout,
    isGestor: ['gestor', 'admin'].includes(state.usuario?.role || ''),
    isAdmin:  state.usuario?.role === 'admin'
  };
}
