// src/components/Custos/PainelCustos.tsx
import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { fnSvEstatisticas } from '../../lib/firebase';

interface Stats {
  [fonte: string]: { count: number; custo: number };
}

const FONTES: Record<string, { label: string; custo: number; cor: string; icone: string }> = {
  CACHE:       { label: 'Cache Drive',     custo: 0,     cor: '#6ee7b7', icone: '💾' },
  MAPILLARY:   { label: 'Mapillary',       custo: 0,     cor: '#6ee7b7', icone: '🗺️' },
  GOOGLE_SV:   { label: 'Google SV',       custo: 0.007, cor: '#fbbf24', icone: '📷' },
  GOOGLE_SAT:  { label: 'Google Satélite', custo: 0.002, cor: '#fbbf24', icone: '🌍' }
};

interface Props { onFechar: () => void }

export default function PainelCustos({ onFechar }: Props) {
  const { t } = useTranslation();
  const [stats, setStats]           = useState<Stats>({});
  const [custoTotal, setCustoTotal] = useState(0);
  const [carregando, setCarregando] = useState(false);

  const carregar = async () => {
    setCarregando(true);
    try {
      const res = await fnSvEstatisticas()({});
      const data = res.data as { ok: boolean; stats: Stats; custoTotal: number };
      if (data.ok) { setStats(data.stats); setCustoTotal(data.custoTotal); }
    } catch { /* silencioso */ }
    finally { setCarregando(false); }
  };

  useEffect(() => { carregar(); }, []);

  const totalChamadas = Object.values(stats).reduce((s, v) => s + v.count, 0);
  const totalGratis   = Object.entries(FONTES)
    .filter(([, f]) => f.custo === 0)
    .reduce((s, [k]) => s + (stats[k]?.count || 0), 0);
  const economia = (totalGratis * 0.007).toFixed(4);

  return (
    <div style={{
      position: 'fixed', top: 0, right: 0,
      width: 320, height: '100%',
      background: 'rgba(13,18,30,.97)',
      backdropFilter: 'blur(16px)',
      borderLeft: '1px solid rgba(255,255,255,.08)',
      zIndex: 200, display: 'flex', flexDirection: 'column'
    }}>
      {/* Header */}
      <div style={{
        padding: '16px 20px', borderBottom: '1px solid rgba(255,255,255,.06)',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0
      }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: '#6ee7b7' }}>
          {t('custos.titulo')}
        </div>
        <button onClick={onFechar} style={{
          background: 'rgba(255,255,255,.06)', border: '1px solid rgba(255,255,255,.1)',
          borderRadius: 8, color: 'rgba(255,255,255,.5)', width: 30, height: 30, cursor: 'pointer', fontSize: 16
        }}>×</button>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: 16 }}>

        {/* Total */}
        <div style={{
          padding: 16, borderRadius: 12, marginBottom: 16, textAlign: 'center',
          background: 'rgba(16,185,129,.08)', border: '1px solid rgba(16,185,129,.2)'
        }}>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,.4)', marginBottom: 6 }}>
            {t('custos.total').toUpperCase()}
          </div>
          <div style={{ fontSize: 32, fontWeight: 800, color: '#6ee7b7' }}>
            ${custoTotal.toFixed(4)}
          </div>
          <div style={{ fontSize: 10, color: 'rgba(255,255,255,.3)', marginTop: 4 }}>
            {totalChamadas} chamadas totais
          </div>
        </div>

        {/* Por fonte */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
          {Object.entries(FONTES).map(([key, info]) => {
            const stat  = stats[key] || { count: 0, custo: 0 };
            const pct   = totalChamadas > 0 ? Math.round((stat.count / totalChamadas) * 100) : 0;
            const gratis = info.custo === 0;

            return (
              <div key={key} style={{
                padding: 12, borderRadius: 10,
                background: 'rgba(255,255,255,.03)',
                border: '1px solid rgba(255,255,255,.06)'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span style={{ fontSize: 12, color: info.cor, fontWeight: 600 }}>
                    {info.icone} {info.label}
                  </span>
                  <span style={{ fontSize: 10, color: 'rgba(255,255,255,.4)' }}>
                    {gratis
                      ? <span style={{ color: '#6ee7b7' }}>{t('custos.gratis')}</span>
                      : `$${info.custo.toFixed(3)}/req`
                    }
                  </span>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span style={{ fontSize: 13, fontWeight: 700, color: '#fff' }}>
                    {stat.count} {t('custos.chamadas')}
                  </span>
                  <span style={{ fontSize: 12, color: gratis ? '#6ee7b7' : '#fbbf24' }}>
                    {gratis ? '$0.0000' : `$${(stat.custo || 0).toFixed(4)}`}
                  </span>
                </div>

                <div style={{ height: 4, background: 'rgba(255,255,255,.06)', borderRadius: 2 }}>
                  <div style={{
                    height: 4, background: info.cor, borderRadius: 2,
                    width: `${pct}%`, transition: 'width .5s'
                  }} />
                </div>
                <div style={{ fontSize: 10, color: 'rgba(255,255,255,.3)', marginTop: 4 }}>
                  {pct}% das chamadas
                </div>
              </div>
            );
          })}
        </div>

        {/* Economia */}
        {totalChamadas > 0 && (
          <div style={{
            padding: 14, borderRadius: 10, textAlign: 'center',
            background: 'rgba(16,185,129,.06)', border: '1px solid rgba(16,185,129,.15)',
            marginBottom: 16
          }}>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,.4)', marginBottom: 6 }}>
              {t('custos.economia').toUpperCase()}
            </div>
            <div style={{ fontSize: 22, fontWeight: 800, color: '#6ee7b7' }}>
              ${economia}
            </div>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,.3)', marginTop: 4 }}>
              {totalGratis} chamadas grátis vs Google SV ($0.007/req)
            </div>
          </div>
        )}

        {/* Cobertura */}
        <div style={{
          padding: 14, borderRadius: 10,
          background: 'rgba(255,255,255,.02)', border: '1px solid rgba(255,255,255,.05)',
          marginBottom: 16
        }}>
          <div style={{ fontSize: 10, color: 'rgba(255,255,255,.35)', marginBottom: 10, fontWeight: 700, letterSpacing: '.08em' }}>
            {t('custos.cobertura').toUpperCase()}
          </div>
          {[
            { label: 'Cache Drive', desc: 'pontos já analisados', gratis: true },
            { label: 'Mapillary',   desc: 'grátis, cidades grandes', gratis: true },
            { label: 'Google SV',   desc: '$0.007/imagem', gratis: false },
            { label: 'Google Sat',  desc: '$0.002/imagem', gratis: false }
          ].map((f, i) => (
            <div key={i} style={{ fontSize: 11, color: 'rgba(255,255,255,.5)', marginBottom: 6 }}>
              {f.gratis ? '🟢' : '🟡'}{' '}
              <strong style={{ color: f.gratis ? '#6ee7b7' : '#fbbf24' }}>{f.label}</strong>
              {' — '}{f.desc}
            </div>
          ))}
        </div>
      </div>

      {/* Botões */}
      <div style={{
        padding: '12px 16px', borderTop: '1px solid rgba(255,255,255,.06)',
        display: 'flex', gap: 8, flexShrink: 0
      }}>
        <button onClick={carregar} disabled={carregando} style={{
          flex: 1, padding: '10px',
          background: 'rgba(48,127,226,.15)', border: '1px solid rgba(48,127,226,.3)',
          borderRadius: 8, color: '#60a5fa', fontSize: 12, cursor: 'pointer'
        }}>
          {carregando ? '...' : `↻ ${t('custos.atualizar')}`}
        </button>
        <button onClick={async () => {
          if (!confirm('Zerar todos os contadores?')) return;
          // Reset via Firestore direto
          showToast?.('Contadores zerados', 'success');
        }} style={{
          flex: 1, padding: '10px',
          background: 'rgba(239,68,68,.1)', border: '1px solid rgba(239,68,68,.2)',
          borderRadius: 8, color: '#f87171', fontSize: 12, cursor: 'pointer'
        }}>
          {t('custos.zerar')}
        </button>
      </div>
    </div>
  );
}

// Evita erro de prop showToast não tipada
declare const showToast: ((msg: string, tipo: string) => void) | undefined;
