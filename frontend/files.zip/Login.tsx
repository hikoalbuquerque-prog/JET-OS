// src/pages/Login.tsx
import { useState, FormEvent } from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../hooks/useAuth';

const IDIOMAS = [
  { code: 'pt', label: 'PT' },
  { code: 'es', label: 'ES' },
  { code: 'en', label: 'EN' },
  { code: 'ru', label: 'RU' }
];

export default function Login() {
  const { t, i18n } = useTranslation();
  const { login, erro, loading } = useAuth();
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    try { await login(email, senha); } catch { /* erro já no state */ }
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #0d1220 0%, #0f1928 100%)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: 'Inter, system-ui, sans-serif'
    }}>
      {/* Seletor de idioma */}
      <div style={{ position: 'absolute', top: 20, right: 20, display: 'flex', gap: 8 }}>
        {IDIOMAS.map(l => (
          <button key={l.code}
            onClick={() => i18n.changeLanguage(l.code)}
            style={{
              padding: '4px 10px', borderRadius: 6,
              background: i18n.language === l.code ? 'rgba(48,127,226,.3)' : 'rgba(255,255,255,.06)',
              border: `1px solid ${i18n.language === l.code ? 'rgba(48,127,226,.5)' : 'rgba(255,255,255,.1)'}`,
              color: i18n.language === l.code ? '#60a5fa' : 'rgba(255,255,255,.5)',
              fontSize: 11, cursor: 'pointer'
            }}
          >{l.label}</button>
        ))}
      </div>

      <div style={{
        width: '100%', maxWidth: 380, padding: '0 20px'
      }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 40 }}>
          <div style={{
            width: 64, height: 64, borderRadius: 16,
            background: 'linear-gradient(135deg, #1a6fd4, #307FE2)',
            margin: '0 auto 16px',
            display: 'flex', alignItems: 'center', justifyContent: 'center'
          }}>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="white">
              <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
            </svg>
          </div>
          <h1 style={{ color: '#fff', fontSize: 22, fontWeight: 700, margin: 0 }}>
            {t('app.nome')}
          </h1>
          <p style={{ color: 'rgba(255,255,255,.4)', fontSize: 13, marginTop: 6 }}>
            Sistema de mapeamento
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', color: 'rgba(255,255,255,.6)', fontSize: 12, marginBottom: 8 }}>
              {t('auth.email')}
            </label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              style={{
                width: '100%', padding: '12px 14px',
                background: 'rgba(255,255,255,.06)',
                border: '1px solid rgba(255,255,255,.1)',
                borderRadius: 10, color: '#fff', fontSize: 14,
                outline: 'none', boxSizing: 'border-box'
              }}
              placeholder="seu@email.com"
            />
          </div>

          <div style={{ marginBottom: 24 }}>
            <label style={{ display: 'block', color: 'rgba(255,255,255,.6)', fontSize: 12, marginBottom: 8 }}>
              {t('auth.senha')}
            </label>
            <input
              type="password"
              value={senha}
              onChange={e => setSenha(e.target.value)}
              required
              style={{
                width: '100%', padding: '12px 14px',
                background: 'rgba(255,255,255,.06)',
                border: '1px solid rgba(255,255,255,.1)',
                borderRadius: 10, color: '#fff', fontSize: 14,
                outline: 'none', boxSizing: 'border-box'
              }}
              placeholder="••••••••"
            />
          </div>

          {erro && (
            <div style={{
              padding: '10px 14px', borderRadius: 8, marginBottom: 16,
              background: 'rgba(239,68,68,.1)', border: '1px solid rgba(239,68,68,.2)',
              color: '#f87171', fontSize: 13
            }}>{erro}</div>
          )}

          <button
            type="submit"
            disabled={loading}
            style={{
              width: '100%', padding: '14px',
              background: loading ? 'rgba(48,127,226,.4)' : 'linear-gradient(135deg,#1a6fd4,#307FE2)',
              border: 'none', borderRadius: 10, color: '#fff',
              fontSize: 15, fontWeight: 600, cursor: loading ? 'not-allowed' : 'pointer'
            }}
          >
            {loading ? t('app.carregando') : t('auth.entrar')}
          </button>
        </form>

        <div style={{ textAlign: 'center', marginTop: 20 }}>
          <button style={{
            background: 'none', border: 'none',
            color: 'rgba(255,255,255,.4)', fontSize: 13, cursor: 'pointer'
          }}>
            {t('auth.semAcesso')}
          </button>
        </div>
      </div>
    </div>
  );
}
