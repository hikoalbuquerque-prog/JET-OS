// src/components/Map/FABGroup.tsx
import { useState } from 'react';
import { useTranslation } from 'react-i18next';

interface Props {
  onAdd: () => void;
  onVarredura: () => void;
  onCustos: () => void;
  onCentralizar: () => void;
  onRecarregar: () => void;
  modoAdd: boolean;
}

export default function FABGroup({ onAdd, onVarredura, onCustos, onCentralizar, onRecarregar, modoAdd }: Props) {
  const { t } = useTranslation();
  const [dialAberto, setDialAberto] = useState(false);

  const btnBase: React.CSSProperties = {
    width: 44, height: 44, borderRadius: '50%',
    border: '1px solid rgba(255,255,255,.12)',
    background: 'rgba(13,18,30,.85)',
    backdropFilter: 'blur(12px)',
    color: 'rgba(255,255,255,.7)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    cursor: 'pointer', transition: '.15s'
  };

  const dialItems = [
    {
      label: t('mapa.centralizar'),
      onClick: onCentralizar,
      icon: <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 8c-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4zm8.94 3A8.994 8.994 0 0 0 13 3.06V1h-2v2.06A8.994 8.994 0 0 0 3.06 11H1v2h2.06A8.994 8.994 0 0 0 11 20.94V23h2v-2.06A8.994 8.994 0 0 0 20.94 13H23v-2h-2.06zM12 19c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7z"/></svg>
    },
    {
      label: t('mapa.recarregar'),
      onClick: onRecarregar,
      icon: <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M17.65 6.35A7.958 7.958 0 0 0 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08A5.99 5.99 0 0 1 12 18c-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>
    },
    {
      label: t('mapa.varreduraIA'),
      onClick: onVarredura,
      style: { color: '#60a5fa' },
      icon: <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
    },
    {
      label: t('mapa.custosAPI'),
      onClick: onCustos,
      style: { color: '#6ee7b7' },
      icon: <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"/></svg>
    }
  ];

  return (
    <>
      {/* FAB principal — Adicionar */}
      <button
        onClick={modoAdd ? undefined : onAdd}
        style={{
          position: 'fixed', right: 20, bottom: 20,
          width: 56, height: 56, borderRadius: '50%',
          background: modoAdd
            ? 'linear-gradient(135deg,#ef4444,#dc2626)'
            : 'linear-gradient(135deg,#1a6fd4,#307FE2)',
          border: 'none', color: '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 4px 24px rgba(48,127,226,.5)',
          cursor: 'pointer', zIndex: 100, transition: '.2s'
        }}
      >
        {modoAdd
          ? <svg viewBox="0 0 24 24" width="24" height="24" fill="white"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
          : <svg viewBox="0 0 24 24" width="24" height="24" fill="white"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
        }
      </button>

      {/* FAB dial toggle */}
      <button
        onClick={() => setDialAberto(d => !d)}
        style={{ ...btnBase, position: 'fixed', right: 76, bottom: 28, zIndex: 100 }}
      >
        <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
          <path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/>
        </svg>
      </button>

      {/* Dial items */}
      {dialAberto && (
        <div style={{
          position: 'fixed', right: 20, bottom: 88, zIndex: 99,
          display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'flex-end'
        }}>
          {dialItems.map((item, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{
                background: 'rgba(13,18,30,.9)', padding: '4px 10px',
                borderRadius: 6, fontSize: 11, color: 'rgba(255,255,255,.6)',
                backdropFilter: 'blur(8px)',
                border: '1px solid rgba(255,255,255,.08)'
              }}>{item.label}</span>
              <button
                onClick={() => { item.onClick(); setDialAberto(false); }}
                style={{ ...btnBase, ...item.style }}
              >
                {item.icon}
              </button>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
