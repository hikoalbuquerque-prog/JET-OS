// src/components/Map/InfoEstacao.tsx
import { useTranslation } from 'react-i18next';
import { Estacao } from '../../pages/Mapa';

interface Props {
  estacao: Estacao;
  onFechar: () => void;
  onGerarSV: () => void;
  onAnalisarIA: () => void;
}

const STATUS_COR: Record<string, string> = {
  SOLICITADO: '#60a5fa',
  APROVADO:   '#22c55e',
  REPROVADO:  '#ef4444',
  INSTALADO:  '#8b5cf6',
  CANCELADO:  '#6b7280'
};

export default function InfoEstacao({ estacao, onFechar, onGerarSV, onAnalisarIA }: Props) {
  const { t } = useTranslation();
  const cor = STATUS_COR[estacao.status] || '#60a5fa';

  return (
    <div style={{
      position: 'fixed', left: 0, right: 0, bottom: 0,
      background: 'rgba(13,18,30,.97)',
      backdropFilter: 'blur(16px)',
      borderTop: '1px solid rgba(255,255,255,.08)',
      borderRadius: '16px 16px 0 0',
      padding: '16px 20px 32px',
      zIndex: 150, maxHeight: '80vh', overflowY: 'auto'
    }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
        <div>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,.4)', marginBottom: 4 }}>
            {estacao.tipo} · {estacao.cidade}
          </div>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#fff', marginBottom: 2 }}>
            {estacao.endereco || estacao.bairro}
          </div>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,.4)' }}>
            {estacao.codigo}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <span style={{
            padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 600,
            background: `${cor}22`, color: cor, border: `1px solid ${cor}44`
          }}>{t(`status.${estacao.status}`)}</span>
          <button onClick={onFechar} style={{
            background: 'rgba(255,255,255,.06)', border: '1px solid rgba(255,255,255,.1)',
            borderRadius: 8, color: 'rgba(255,255,255,.5)',
            width: 30, height: 30, cursor: 'pointer', fontSize: 16
          }}>×</button>
        </div>
      </div>

      {/* Foto Street View */}
      {estacao.imagens?.streetView && (
        <img
          src={estacao.imagens.streetView}
          alt="Street View"
          style={{ width: '100%', height: 160, objectFit: 'cover', borderRadius: 10, marginBottom: 12 }}
        />
      )}

      {/* IA resultado */}
      {estacao.ia && (
        <div style={{
          padding: 12, borderRadius: 10, marginBottom: 12,
          background: estacao.ia.aprovado ? 'rgba(16,185,129,.08)' : 'rgba(245,158,11,.08)',
          border: `1px solid ${estacao.ia.aprovado ? 'rgba(16,185,129,.2)' : 'rgba(245,158,11,.2)'}`
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
            <span style={{
              fontSize: 11, fontWeight: 700,
              color: estacao.ia.aprovado ? '#6ee7b7' : '#fbbf24'
            }}>
              {estacao.ia.aprovado ? '✓ ' + t('ia.aprovado') : '⚠ ' + t('ia.reprovado')}
            </span>
            <span style={{ fontSize: 11, color: 'rgba(255,255,255,.4)' }}>
              Score: {estacao.ia.score}
            </span>
          </div>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,.5)' }}>
            {t('ia.largura')}: {estacao.ia.largura || t('ia.indefinido')} ·{' '}
            {t('ia.confianca')} {t(`ia.${estacao.ia.confianca}`)}
          </div>
        </div>
      )}

      {/* Largura faixa */}
      {estacao.larguraFaixa && (
        <div style={{ fontSize: 13, color: 'rgba(255,255,255,.5)', marginBottom: 12 }}>
          {t('estacao.larguraFaixa')}: <strong style={{ color: '#fff' }}>{estacao.larguraFaixa}m</strong>
        </div>
      )}

      {/* Ações */}
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        <button onClick={onAnalisarIA} style={{
          flex: 1, minWidth: 140, padding: '10px 14px',
          background: 'rgba(48,127,226,.15)',
          border: '1px solid rgba(48,127,226,.3)',
          borderRadius: 10, color: '#60a5fa', fontSize: 12, cursor: 'pointer'
        }}>
          {t('estacao.analisarIA')}
        </button>
        <button onClick={onGerarSV} style={{
          flex: 1, minWidth: 140, padding: '10px 14px',
          background: 'rgba(255,255,255,.04)',
          border: '1px solid rgba(255,255,255,.1)',
          borderRadius: 10, color: 'rgba(255,255,255,.6)', fontSize: 12, cursor: 'pointer'
        }}>
          {t('estacao.gerarStreetView')}
        </button>
      </div>
    </div>
  );
}
