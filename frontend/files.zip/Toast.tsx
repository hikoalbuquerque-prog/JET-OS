// src/components/Map/Toast.tsx
interface Props { msg: string; tipo: 'success' | 'error' | 'warn' | 'info' }

const CORES = {
  success: { bg: 'rgba(16,185,129,.15)', border: 'rgba(16,185,129,.3)', text: '#6ee7b7' },
  error:   { bg: 'rgba(239,68,68,.15)',  border: 'rgba(239,68,68,.3)',  text: '#f87171' },
  warn:    { bg: 'rgba(245,158,11,.15)', border: 'rgba(245,158,11,.3)', text: '#fbbf24' },
  info:    { bg: 'rgba(48,127,226,.15)', border: 'rgba(48,127,226,.3)', text: '#60a5fa' }
};

export default function Toast({ msg, tipo }: Props) {
  const c = CORES[tipo];
  return (
    <div style={{
      position: 'fixed', bottom: 90, left: '50%',
      transform: 'translateX(-50%)',
      padding: '10px 18px',
      background: c.bg, border: `1px solid ${c.border}`,
      borderRadius: 10, color: c.text,
      fontSize: 13, fontWeight: 500,
      backdropFilter: 'blur(12px)',
      zIndex: 200, maxWidth: '90vw',
      textAlign: 'center',
      animation: 'fadeIn .2s ease'
    }}>
      {msg}
      <style>{`@keyframes fadeIn { from { opacity:0; transform:translateX(-50%) translateY(8px) } to { opacity:1; transform:translateX(-50%) translateY(0) } }`}</style>
    </div>
  );
}
