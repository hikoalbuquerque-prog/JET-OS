// src/App.tsx
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthCtx, useAuthProvider } from './hooks/useAuth';
import Login from './pages/Login';
import MapaPage from './pages/Mapa';
import '../src/i18n';

function RotaProtegida({ children }: { children: React.ReactNode }) {
  const auth = useAuthProvider();
  if (auth.loading) {
    return (
      <div style={{
        minHeight: '100vh',
        background: '#0d1220',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: 'rgba(255,255,255,.4)', fontSize: 14
      }}>
        Carregando...
      </div>
    );
  }
  return auth.user ? <>{children}</> : <Navigate to="/login" replace />;
}

export default function App() {
  const auth = useAuthProvider();

  return (
    <AuthCtx.Provider value={auth}>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={
            <RotaProtegida><MapaPage /></RotaProtegida>
          } />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthCtx.Provider>
  );
}
