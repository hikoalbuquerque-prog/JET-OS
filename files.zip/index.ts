// src/index.ts — entrada de todas as Cloud Functions
import * as admin from 'firebase-admin';
import * as functions from 'firebase-functions';

// Inicializa Firebase Admin uma vez
admin.initializeApp();

// Imports das funções de negócio
import { addEstacao, gerarStreetView, analisarCalcada, getEstacoes, editarEstacao, excluirEstacao } from './estacoes';
import { getUsuario, solicitarAcesso, aprovarSolicitacao, listarSolicitacoesPendentes, listarUsuarios } from './auth';
import { svGetEstatisticas } from './streetview';
import { analisarCalcadaIA } from './ia';

// Região São Paulo
const regionConfig = functions.region('southamerica-east1');

// ── HELPER: extrai uid e email do contexto auth ──────────────────
function getAuth(context: functions.https.CallableContext) {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Login necessário.');
  return { uid: context.auth.uid, email: context.auth.token.email || '' };
}

function checkRole(
  context: functions.https.CallableContext,
  roles: string[]
): Promise<void> {
  return admin.firestore()
    .collection('usuarios').doc(context.auth!.uid).get()
    .then(doc => {
      if (!doc.exists || !roles.includes(doc.data()!.role)) {
        throw new functions.https.HttpsError('permission-denied', 'Permissão negada.');
      }
    });
}

// ── ESTAÇÕES ─────────────────────────────────────────────────────

export const addEstacaoFn = regionConfig.https.onCall(async (data, context) => {
  const { uid, email } = getAuth(context);
  return addEstacao(data, uid, email);
});

export const editarEstacaoFn = regionConfig.https.onCall(async (data, context) => {
  const { uid, email } = getAuth(context);
  return editarEstacao(data.codigo, data.campos, uid, email);
});

export const excluirEstacaoFn = regionConfig.https.onCall(async (data, context) => {
  const { uid, email } = getAuth(context);
  await checkRole(context, ['gestor', 'admin']);
  return excluirEstacao(data.codigo, uid, email);
});

export const getEstacoesFn = regionConfig.https.onCall(async (data, context) => {
  getAuth(context);
  return getEstacoes(data?.cidade, data?.pais);
});

// ── STREET VIEW ──────────────────────────────────────────────────

export const gerarStreetViewFn = regionConfig.https.onCall(async (data, context) => {
  const { uid, email } = getAuth(context);
  return gerarStreetView(data.codigo, Number(data.lat), Number(data.lng), uid, email);
});

export const svEstatisticasFn = regionConfig.https.onCall(async (_data, context) => {
  getAuth(context);
  return svGetEstatisticas();
});

// ── IA ───────────────────────────────────────────────────────────

export const analisarCalcadaFn = regionConfig.https.onCall(async (data, context) => {
  const { uid, email } = getAuth(context);
  return analisarCalcada(
    data.codigo || null,
    Number(data.lat), Number(data.lng),
    uid, email
  );
});

// ── AUTH ─────────────────────────────────────────────────────────

export const getUsuarioFn = regionConfig.https.onCall(async (_data, context) => {
  const { uid } = getAuth(context);
  return getUsuario(uid);
});

export const solicitarAcessoFn = regionConfig.https.onCall(async (data, _context) => {
  return solicitarAcesso(data);
});

export const aprovarSolicitacaoFn = regionConfig.https.onCall(async (data, context) => {
  const { uid, email } = getAuth(context);
  await checkRole(context, ['gestor', 'admin']);
  return aprovarSolicitacao(data.solicitacaoId, uid, email);
});

export const listarSolicitacoesFn = regionConfig.https.onCall(async (_data, context) => {
  getAuth(context);
  await checkRole(context, ['gestor', 'admin']);
  return listarSolicitacoesPendentes();
});

export const listarUsuariosFn = regionConfig.https.onCall(async (_data, context) => {
  getAuth(context);
  await checkRole(context, ['admin']);
  return listarUsuarios();
});

// ── GEOCODE REVERSO (público via HTTPS) ──────────────────────────
export const reverseGeocodeFn = regionConfig.https.onCall(async (data, context) => {
  getAuth(context);
  const { default: axios } = await import('axios');
  const GMAPS_KEY = process.env.GMAPS_KEY || '';
  const { lat, lng } = data;

  const resp = await axios.get(
    'https://maps.googleapis.com/maps/api/geocode/json',
    { params: { latlng: `${lat},${lng}`, key: GMAPS_KEY } }
  );

  const results = resp.data?.results || [];
  if (!results.length) return { ok: false, error: 'Sem resultados.' };

  const comps = results[0].address_components || [];
  const get = (type: string) =>
    comps.find((c: {types: string[]; long_name: string}) => c.types.includes(type))?.long_name || '';

  const pais = get('country') === 'MX' ? 'MX' : 'BR';
  return {
    ok: true,
    geo: {
      endereco:  results[0].formatted_address || '',
      bairro:    get('sublocality_level_1') || get('neighborhood') || '',
      cidade:    get('locality') || get('administrative_area_level_2') || '',
      estado:    get('administrative_area_level_1') || '',
      pais,
      alcaldia:  pais === 'MX' ? get('administrative_area_level_2') : ''
    }
  };
});
